function a = lassign(X, mu0, Sigma0, mu1, Sigma1)
a = zeros(1,size(X,2));
end
